public class Bus
{
    private int busID;
    private String model;

    public Bus(int ID, String Model)
    {
        busID = ID;
        model = Model;
    }

    public int getID()
    {
        return busID;
    }
}
